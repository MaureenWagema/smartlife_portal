﻿SmartLife.creditlife_req_claim_form = function (params) {
    "use strict";

    var viewModel = {
//  Put the binding properties here
    };

    return viewModel;
};
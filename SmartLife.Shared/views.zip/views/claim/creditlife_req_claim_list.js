﻿SmartLife.creditlife_req_claim_list = function (params) {
    "use strict";

    var viewModel = {
//  Put the binding properties here
    };

    return viewModel;
};
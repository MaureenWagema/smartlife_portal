﻿SmartLife.main_dashboard = function (params) {
    "use strict";

    var viewModel = {
//  Put the binding properties here
    };

    return viewModel;
};